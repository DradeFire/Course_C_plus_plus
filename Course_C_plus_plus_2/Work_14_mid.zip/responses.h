#pragma once
#include <stdlib.h>
#include <set>
#include <stdexcept>
#include <algorithm>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <map>

using namespace std;

struct StopsForBusResponse{
    std::string bus;
    std::vector<std::pair<std::string, std::vector<std::string>>> stops_for_buses;
};

struct BusesForStopResponse{
    std::vector<std::string> buses;
};

struct AllBusesResponse{
    std::map<std::string, std::vector<std::string>> buses_to_stops;
};

//struct BusesForStopResponse;

std::ostream& operator << (std::ostream& os, const BusesForStopResponse& r);

//struct StopsForBusResponse;

std::ostream& operator << (std::ostream& os, const StopsForBusResponse& r);

//struct AllBusesResponse;

std::ostream& operator << (std::ostream& os, const AllBusesResponse& r);
